# Spring Cloud Project Generator

根据库表自动生成项目工程、代码和文档

## version

### 1.0.0

* pom.xml
* application.properties
* application-dev.properties
* application-test.properties
* bootstrap.properties
* mapper文件
* Application类
* 实体类
* Mapper类
* Controller类
* Service类
