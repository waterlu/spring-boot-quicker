package cn.zjhf.tool.quicker.core;

import cn.zjhf.tool.quicker.dto.GeneratorParam;
import cn.zjhf.tool.quicker.model.DataModel;
import cn.zjhf.tool.quicker.model.JavaClassModel;
import com.google.common.base.CaseFormat;
import com.google.common.base.Splitter;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by lutiehua on 2017/9/28.
 */
public class GeneratedJavaAppClass extends GeneratedFile {

    private JavaClassModel model;

    private String fileName;

    public GeneratedJavaAppClass(GeneratorParam generatorParam) {
        super(generatorParam);

        model = new JavaClassModel();

        Date now = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String date = dateFormat.format(now);
        String packageName = generatorParam.getPackageInfo().getBasePackage();
        String author = generatorParam.getPackageInfo().getAuthor();
        String projectName = generatorParam.getProjectInfo().getName();
        projectName = CaseFormat.LOWER_HYPHEN.to(CaseFormat.UPPER_CAMEL, projectName.toLowerCase());
        String className = projectName + "Application";
        String classRemark = generatorParam.getProjectInfo().getDescription();

        model.setPackageName(packageName);
        model.setAuthor(author);
        model.setDate(date);
        model.setClassName(className);
        model.setClassRemark(classRemark);

        String rootDir = generatorParam.getPackageInfo().getProjectPath();
        String javaPath = generatorParam.getPackageInfo().getJavaPath();
        List<String> list = Splitter.on(".").splitToList(packageName);
        StringBuffer buffer = new StringBuffer();
        for (String path : list) {
            buffer.append(path);
            buffer.append("/");
        }
        String packagePath = buffer.toString();
        fileName = rootDir + "/" + javaPath + "/" + packagePath + className + ".java";
    }

    /**
     * 模板
     *
     * @return
     */
    @Override
    public String getTemplateName() {
        return "app.ftl";
    }

    /**
     * 变量数据
     *
     * @return
     */
    @Override
    public DataModel getDataModel() {
        return model;
    }

    /**
     * 文件名称
     *
     * @return
     */
    @Override
    public String getFileName() {
        return fileName;
    }
}
