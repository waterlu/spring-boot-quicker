package cn.zjhf.tool.quicker.core;

import cn.zjhf.tool.quicker.dto.GeneratorParam;
import cn.zjhf.tool.quicker.dto.TableInfo;
import org.springframework.stereotype.Component;

/**
 * 生成项目文件
 *
 * Created by lutiehua on 2017/11/10.
 */
@Component
public class ServiceGenerator implements Generator {

    /**
     * 自动生成代码
     *
     * @param generatorParam
     */
    @Override
    public void generateCode(GeneratorParam generatorParam) throws Exception {
        for (TableInfo tableInfo : generatorParam.getTables()) {
            generateService(generatorParam, tableInfo);
        }
    }

    private void generateService(GeneratorParam generatorParam, TableInfo tableInfo) throws Exception {
        // Service
        GeneratedJavaServiceClass javaServiceClass = new GeneratedJavaServiceClass(generatorParam, tableInfo);
        javaServiceClass.generateFile();

        // ServiceImpl
        GeneratedJavaServiceImplClass javaServiceImplClass = new GeneratedJavaServiceImplClass(generatorParam, tableInfo);
        javaServiceImplClass.generateFile();
    }
}