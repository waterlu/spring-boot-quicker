package cn.zjhf.tool.quicker.api;

import cn.zjhf.tool.quicker.common.ResponseResult;
import cn.zjhf.tool.quicker.dto.DatabaseInfo;
import cn.zjhf.tool.quicker.entity.DBField;
import cn.zjhf.tool.quicker.entity.DBTable;
import cn.zjhf.tool.quicker.common.DBType;
import org.springframework.web.bind.annotation.*;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * Created by lutiehua on 2017/9/22.
 */
@RestController
@RequestMapping("/api/database")
public class DatabaseController {

    @RequestMapping(value = "/connect", method = RequestMethod.POST)
    public ResponseResult connect(@RequestBody DatabaseInfo databaseInfo) throws Exception {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseResult.OK);
        responseResult.setData(getConnection(databaseInfo).getSchema());
        return responseResult;
    }

    @RequestMapping(value = "/tables", method = RequestMethod.POST)
    public ResponseResult getTables(@RequestBody DatabaseInfo databaseInfo) throws Exception {
        List<DBTable> tableList = getTableNames(databaseInfo);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseResult.OK);
        responseResult.setData(tableList);
        return responseResult;
    }

    @RequestMapping(value = "/tables/{tableName}", method = RequestMethod.POST)
    public ResponseResult getTableColumns(@PathVariable String tableName, @RequestBody DatabaseInfo databaseInfo) throws Exception {
        List<DBField> fieldList = getTableColumns(databaseInfo, tableName);
        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseResult.OK);
        responseResult.setData(fieldList);
        return responseResult;
    }

    private Connection getConnection(DatabaseInfo databaseInfo) throws Exception {
        DriverManager.setLoginTimeout(3);
        DBType dbType = DBType.valueOf(databaseInfo.getDbType());
        Class.forName(dbType.getDriverClass());
        String url = getConnectionURL(databaseInfo);
        Properties props =new Properties();
        props.setProperty("user", databaseInfo.getDbUsername());
        props.setProperty("password", databaseInfo.getDbPassword());
        //设置可以获取remarks信息
        props.setProperty("remarks", "true");
        //设置可以获取tables remarks信息
        props.setProperty("useInformationSchema", "true");
        Connection connection = DriverManager.getConnection(url, props);
        return connection;
    }

    private String getConnectionURL(DatabaseInfo databaseInfo) throws ClassNotFoundException {
        DBType dbType = DBType.valueOf(databaseInfo.getDbType());
        String connectionRUL = String.format(dbType.getConnectionUrlPattern(), databaseInfo.getDbIP(),
                databaseInfo.getDbPort(), databaseInfo.getDbName());
        return connectionRUL;
    }

    private List<DBTable> getTableNames(DatabaseInfo databaseInfo) throws Exception {
        Connection connection = getConnection(databaseInfo);
        List<DBTable> tables = new ArrayList<>();
        DatabaseMetaData metaData = connection.getMetaData();
        String[] types = { "TABLE", "VIEW" };
        ResultSet resultSet = metaData.getTables(null, databaseInfo.getDbUsername().toUpperCase(), null, types);
        while (resultSet.next()) {
            DBTable table = new DBTable();
            table.setName(resultSet.getString("TABLE_NAME"));
            table.setType(resultSet.getString("TABLE_TYPE"));
            table.setRemark(resultSet.getString("REMARKS"));
            tables.add(table);
        }
        return tables;
    }

    private List<DBField> getTableColumns(DatabaseInfo databaseInfo, String tableName) throws Exception {
        Connection connection = getConnection(databaseInfo);
        DatabaseMetaData metaData = connection.getMetaData();
        String primaryKeyFiledName = getTablePrimaryKey(metaData, tableName);
        ResultSet resultSet = metaData.getColumns(null, null, tableName, null);
        List<DBField> fieldList = new ArrayList<>();
        while (resultSet.next()) {
            DBField field = new DBField();
            field.setColumnName(resultSet.getString("COLUMN_NAME"));
            field.setTypeName(resultSet.getString("TYPE_NAME"));
            field.setColumnSize(resultSet.getInt("COLUMN_SIZE"));
            field.setDecimalDigits(resultSet.getInt("DECIMAL_DIGITS"));
            field.setNullableShow(resultSet.getString("IS_NULLABLE"));
            field.setRemarks(resultSet.getString("REMARKS"));
            if (null != primaryKeyFiledName) {
                if (field.getColumnName().equalsIgnoreCase(primaryKeyFiledName)) {
                    field.setPrimaryKeyShow("Y");
                } else {
                    field.setPrimaryKeyShow("");
                }
            }
            fieldList.add(field);
        }

        return fieldList;
    }

    private String getTablePrimaryKey(DatabaseMetaData metaData, String tableName) throws Exception {
        ResultSet rs = metaData.getPrimaryKeys(null, null, tableName);
        while (rs.next()) {
            return rs.getString("COLUMN_NAME");
        }
        return null;
    }
}
