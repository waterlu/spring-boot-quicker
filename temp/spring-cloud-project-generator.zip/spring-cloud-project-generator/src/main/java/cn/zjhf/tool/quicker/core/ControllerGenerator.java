package cn.zjhf.tool.quicker.core;

import cn.zjhf.tool.quicker.dto.GeneratorParam;
import cn.zjhf.tool.quicker.dto.TableInfo;
import org.springframework.stereotype.Component;

/**
 * 生成项目文件
 *
 * Created by lutiehua on 2017/11/10.
 */
@Component
public class ControllerGenerator implements Generator {

    /**
     * 自动生成代码
     *
     * @param generatorParam
     */
    @Override
    public void generateCode(GeneratorParam generatorParam) throws Exception {
        for (TableInfo tableInfo : generatorParam.getTables()) {
            generateController(generatorParam, tableInfo);
        }
    }

    private void generateController(GeneratorParam generatorParam, TableInfo tableInfo) throws Exception {
        // Controller
        GeneratedJavaControllerClass javaControllerClass = new GeneratedJavaControllerClass(generatorParam, tableInfo);
        javaControllerClass.generateFile();
    }
}