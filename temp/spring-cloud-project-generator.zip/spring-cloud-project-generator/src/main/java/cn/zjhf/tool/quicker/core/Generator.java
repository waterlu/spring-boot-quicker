package cn.zjhf.tool.quicker.core;

import cn.zjhf.tool.quicker.dto.GeneratorParam;

/**
 * 通用接口
 *
 * Created by lutiehua on 2017/11/10.
 */
public interface Generator {

    /**
     * 自动生成代码
     *
     * @param generatorParam
     */
    void generateCode(GeneratorParam generatorParam) throws Exception;
}
