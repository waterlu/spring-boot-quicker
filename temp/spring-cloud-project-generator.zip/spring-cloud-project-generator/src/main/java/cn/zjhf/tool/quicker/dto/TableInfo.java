package cn.zjhf.tool.quicker.dto;

import lombok.Data;

/**
 * 数据库表信息
 *
 * Created by lutiehua on 2017/11/9.
 */
@Data
public class TableInfo {

    /**
     * 名称
     */
    private String name;

    /**
     * 注释
     */
    private String remark;
}
