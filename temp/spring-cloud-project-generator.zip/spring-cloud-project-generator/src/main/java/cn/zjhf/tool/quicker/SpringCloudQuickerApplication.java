package cn.zjhf.tool.quicker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudQuickerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudQuickerApplication.class, args);
	}
}
