package cn.zjhf.tool.quicker.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Java类数据模型
 *
 * Created by lutiehua on 2017/9/26.
 */
@Getter
@Setter
@NoArgsConstructor
public class JavaClassModel extends DataModel {

    /**
     * 包名
     */
    protected String packageName;

    /**
     * 类名
     */
    protected String className;

    /**
     * 类注释
     */
    protected String classRemark;

    /**
     * 需要引入的包
     */
    protected List<JavaImport> imports = new ArrayList<>();

    /**
     * 类成员变量
     */
    protected List<JavaField> fields = new ArrayList<>();

    /**
     * 类成员方法
     */
    protected List<JavaMethod> methods = new ArrayList<>();

    /**
     * 类对象名
     */
    protected String objectName;

    /**
     * 实体类名
     */
    protected String modelClassName;

    /**
     * 实体类对象名
     */
    protected String modelObjectName;

    /**
     * 服务类名
     */
    protected String serviceClassName;

    /**
     * 服务类对象名
     */
    protected String serviceObjectName;

    /**
     * 持久化类名
     */
    protected String mapperClassName;

    /**
     * 持久化类对象名
     */
    protected String mapperObjectName;
}
