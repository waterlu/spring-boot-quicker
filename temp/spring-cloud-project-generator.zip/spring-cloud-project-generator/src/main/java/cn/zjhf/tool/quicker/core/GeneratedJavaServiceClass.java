package cn.zjhf.tool.quicker.core;

import cn.zjhf.tool.quicker.dto.GeneratorParam;
import cn.zjhf.tool.quicker.dto.TableInfo;
import cn.zjhf.tool.quicker.model.DataModel;
import cn.zjhf.tool.quicker.model.JavaClassModel;
import cn.zjhf.tool.quicker.model.JavaImport;
import com.google.common.base.CaseFormat;
import com.google.common.base.Splitter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by lutiehua on 2017/9/28.
 */
public class GeneratedJavaServiceClass extends GeneratedFile {

    private JavaClassModel model;

    private String fileName;

    public GeneratedJavaServiceClass(GeneratorParam generatorParam) {
        super(generatorParam);
    }

    public GeneratedJavaServiceClass(GeneratorParam generatorParam, TableInfo tableInfo) {
        super(generatorParam);

        model = new JavaClassModel();

        Date now = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String date = dateFormat.format(now);
        String basePackageName = generatorParam.getPackageInfo().getBasePackage();
        String author = generatorParam.getPackageInfo().getAuthor();
        String servicePackageName = generatorParam.getPackageInfo().getServicePackage();
        String packageName = basePackageName + "." + servicePackageName;

        String tableName = tableInfo.getName();
        String classRemark = tableInfo.getRemark();
        String modelClassName = CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, tableName.toLowerCase());
        String className = modelClassName + "Service";

        model.setPackageName(packageName);
        model.setAuthor(author);
        model.setDate(date);
        model.setClassName(className);
        model.setClassRemark(classRemark);
        model.setModelClassName(modelClassName);

        // 分析依赖包
        List<JavaImport> importList = new ArrayList<>();
        JavaImport javaImport = null;

        // 实体类
        javaImport = new JavaImport();
        String modelPackageName = basePackageName + "." + generatorParam.getPackageInfo().getEntityPackage();
        javaImport.setName(modelPackageName + "." + modelClassName);
        importList.add(javaImport);

        model.setImports(importList);

        String rootDir = generatorParam.getPackageInfo().getProjectPath();
        String javaPath = generatorParam.getPackageInfo().getJavaPath();
        List<String> list = Splitter.on(".").splitToList(packageName);
        StringBuffer buffer = new StringBuffer();
        for (String path : list) {
            buffer.append(path);
            buffer.append("/");
        }
        String packagePath = buffer.toString();
        fileName = rootDir + "/" + javaPath + "/" + packagePath + className + ".java";
    }

    /**
     * 模板
     *
     * @return
     */
    @Override
    public String getTemplateName() {
        return "service.ftl";
    }

    /**
     * 变量数据
     *
     * @return
     */
    @Override
    public DataModel getDataModel() {
        return model;
    }

    /**
     * 文件名称
     *
     * @return
     */
    @Override
    public String getFileName() {
        return fileName;
    }
}
