package cn.zjhf.tool.quicker.dto;

import lombok.Data;

/**
 * 程序包信息
 *
 * Created by lutiehua on 2017/9/25.
 */
@Data
public class PackageInfo {

    /**
     * 项目路径
     */
    private String projectPath;

    /**
     * 基础包名
     */
    private String basePackage;

    /**
     * config包名
     */
    private String configPackage;

    /**
     * controller包名
     */
    private String controllerPackage;

    /**
     * service包名
     */
    private String servicePackage;

    /**
     * dao包名
     */
    private String daoPackage;

    /**
     * entity包名
     */
    private String entityPackage;

//    /**
//     *
//     */
//    private String dtoPackage;

    /**
     * 作者
     */
    private String author;

    /**
     * JAVA源文件路径
     */
    private String javaPath;

    /**
     * 资源文件路径
     */
    private String resourcePath;

    /**
     * 测试类路径
     */
    private String testPath;

}
