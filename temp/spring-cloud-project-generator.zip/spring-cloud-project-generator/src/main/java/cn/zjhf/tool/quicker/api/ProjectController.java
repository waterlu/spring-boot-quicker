package cn.zjhf.tool.quicker.api;

import cn.zjhf.tool.quicker.common.ResponseResult;
import cn.zjhf.tool.quicker.core.*;
import cn.zjhf.tool.quicker.dto.GeneratorParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

/**
 * Created by lutiehua on 2017/9/22.
 */
@RestController
@RequestMapping("/api/project")
public class ProjectController extends BaseController {

    @Autowired
    private MybatisGenerator mybatisGenerator;

    @Autowired
    private ProjectGenerator projectGenerator;

    @Autowired
    private ControllerGenerator controllerGenerator;

    @Autowired
    private ServiceGenerator serviceGenerator;

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public ResponseResult generate(@RequestBody Map<String, Object> param) throws Exception {

        GeneratorParam generatorParam = super.getParamObject(param, GeneratorParam.class);

        // 生成项目文件
        projectGenerator.generateCode(generatorParam);

        // 生成CRUD
        mybatisGenerator.generateCode(generatorParam);

        // 生成Service
        serviceGenerator.generateCode(generatorParam);

        // 生成Controller
        controllerGenerator.generateCode(generatorParam);

        ResponseResult responseResult = new ResponseResult();
        responseResult.setCode(ResponseResult.OK);
        responseResult.setData("ok");
        return responseResult;
    }
}