package cn.zjhf.tool.quicker.dto;

import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

/**
 * 项目信息
 *
 * Created by lutiehua on 2017/9/26.
 */
@Data
public class ProjectInfo {

    @NotBlank
    private String groupId;

    @NotBlank
    private String artifactId;

    /**
     * 服务端口
     */
    @NotBlank
    private Integer port;

    @NotBlank
    private String version;

    private String name;

    private String description;

    /**
     * JDK 版本
     */
    private String javaVersion;

    /**
     * Spring Boot 版本
     */
    private String springBootVersion;
}
