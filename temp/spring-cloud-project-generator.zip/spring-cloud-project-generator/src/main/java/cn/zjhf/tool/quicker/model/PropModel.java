package cn.zjhf.tool.quicker.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Created by lutiehua on 2017/11/10.
 */
@Getter
@Setter
@NoArgsConstructor
public class PropModel extends DataModel {

    /**
     * 服务名称
     */
    private String serviceName;

    /**
     * 服务端口
     */
    private int servicePort;

    /**
     * 监控端口
     */
    private int managePort;

    /**
     * 数据库名
     */
    private String dbName;

}
