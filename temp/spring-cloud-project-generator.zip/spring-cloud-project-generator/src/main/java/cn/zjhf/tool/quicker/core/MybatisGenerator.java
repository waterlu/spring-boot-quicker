package cn.zjhf.tool.quicker.core;

import cn.zjhf.tool.quicker.dto.GeneratorParam;
import cn.zjhf.tool.quicker.dto.TableInfo;
import cn.zjhf.tool.quicker.util.DBUtil;
import com.google.common.base.CaseFormat;
import com.google.common.base.Strings;
import org.mybatis.generator.api.MyBatisGenerator;
import org.mybatis.generator.config.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * 生成实体类对象和MAPPER文件
 *
 * Created by lutiehua on 2017/11/9.
 */
@Component
public class MybatisGenerator implements Generator{

    /**
     * 通用Mapper基类
     */
    private final static String MAPPER_INTERFACE_REFERENCE = "cn.zjhf.kingold.cloud.common.persistence.Mapper";

    @Autowired
    private MybatisShellCallback shellCallback;

    @Autowired
    private MybatisProgressCallback progressCallback;

    /**
     * 自动生成代码
     *
     * @param generatorParam
     */
    @Override
    public void generateCode(GeneratorParam generatorParam) throws Exception {
        for (TableInfo tableInfo : generatorParam.getTables()) {
            generateModelAndMapper(generatorParam, tableInfo);
        }
    }

    /**
     * 根据表结构自动生成持久化代码
     *
     * @param generatorParam
     * @param tableInfo
     */
    private void generateModelAndMapper(GeneratorParam generatorParam, TableInfo tableInfo) {
        Context context = new Context(ModelType.FLAT);
        context.setId("waterlu");
        context.setTargetRuntime("MyBatis3Simple");
        context.addProperty(PropertyRegistry.CONTEXT_BEGINNING_DELIMITER, "`");
        context.addProperty(PropertyRegistry.CONTEXT_ENDING_DELIMITER, "`");

        // 数据库连接配置，目前只支持MySQL
        JDBCConnectionConfiguration jdbcConnectionConfiguration = new JDBCConnectionConfiguration();
        String dbIP = generatorParam.getDatabaseInfo().getDbIP();
        int dbPort = generatorParam.getDatabaseInfo().getDbPort();
        String dbName = generatorParam.getDatabaseInfo().getDbName();
        String jdbcUrl = String.format("jdbc:mysql://%s:%d/%s", dbIP, dbPort, dbName);
        String dbUsername = generatorParam.getDatabaseInfo().getDbUsername();
        String dbPassword = generatorParam.getDatabaseInfo().getDbPassword();
        jdbcConnectionConfiguration.setConnectionURL(jdbcUrl);
        jdbcConnectionConfiguration.setUserId(dbUsername);
        jdbcConnectionConfiguration.setPassword(dbPassword);
        jdbcConnectionConfiguration.setDriverClass("com.mysql.jdbc.Driver");
        context.setJdbcConnectionConfiguration(jdbcConnectionConfiguration);

        // TKMybatis插件
        PluginConfiguration pluginConfiguration = new PluginConfiguration();
        pluginConfiguration.setConfigurationType("tk.mybatis.mapper.generator.MapperPlugin");
        pluginConfiguration.addProperty("mappers", MAPPER_INTERFACE_REFERENCE);
        context.addPluginConfiguration(pluginConfiguration);

        // Java实体类
        JavaModelGeneratorConfiguration javaModelGeneratorConfiguration = new JavaModelGeneratorConfiguration();
        String projectPath = generatorParam.getPackageInfo().getProjectPath();
        String javaPath = generatorParam.getPackageInfo().getJavaPath();
        javaModelGeneratorConfiguration.setTargetProject(projectPath + "/" + javaPath);
        String basePackage = generatorParam.getPackageInfo().getBasePackage();
        String entityPackage = generatorParam.getPackageInfo().getEntityPackage();
        javaModelGeneratorConfiguration.setTargetPackage(basePackage + "." + entityPackage);
        context.setJavaModelGeneratorConfiguration(javaModelGeneratorConfiguration);

        // Mapper.xml文件
        SqlMapGeneratorConfiguration sqlMapGeneratorConfiguration = new SqlMapGeneratorConfiguration();
        String resourcePath = generatorParam.getPackageInfo().getResourcePath();
        sqlMapGeneratorConfiguration.setTargetProject(projectPath + "/" +  resourcePath);
        sqlMapGeneratorConfiguration.setTargetPackage("mybatis/mapper");
        context.setSqlMapGeneratorConfiguration(sqlMapGeneratorConfiguration);

        // JAVA Mapper类
        JavaClientGeneratorConfiguration javaClientGeneratorConfiguration = new JavaClientGeneratorConfiguration();
        javaClientGeneratorConfiguration.setTargetProject(projectPath + "/" + javaPath);
        String daoPackage = generatorParam.getPackageInfo().getDaoPackage();
        javaClientGeneratorConfiguration.setTargetPackage(basePackage + "." + daoPackage);
        javaClientGeneratorConfiguration.setConfigurationType("XMLMAPPER");
        context.setJavaClientGeneratorConfiguration(javaClientGeneratorConfiguration);

        // 数据源表
        String tableName = tableInfo.getName();
        String modelName = CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, tableName.toLowerCase());
        TableConfiguration tableConfiguration = new TableConfiguration(context);
        tableConfiguration.setTableName(tableName);
        if (!Strings.isNullOrEmpty(modelName)) {
            tableConfiguration.setDomainObjectName(modelName);
        }
        tableConfiguration.setGeneratedKey(new GeneratedKey("id", "Mysql", true, null));
        context.addTableConfiguration(tableConfiguration);

        List<String> warnings = new ArrayList<>();
        MyBatisGenerator generator;
        try {
            Configuration config = new Configuration();
            config.addContext(context);
            config.validate();

            generator = new MyBatisGenerator(config, shellCallback, warnings);
            generator.generate(progressCallback);
        } catch (Exception e) {
            throw new RuntimeException("生成Model和Mapper失败", e);
        }

        if (generator.getGeneratedJavaFiles().isEmpty() || generator.getGeneratedXmlFiles().isEmpty()) {
            throw new RuntimeException("生成Model和Mapper失败：" + warnings);
        }
        if (Strings.isNullOrEmpty(modelName)) {
            modelName = tableNameConvertUpperCamel(tableName);
        }
    }

    /**
     * 数据库表名 => 实体对象名
     * lower_underscore => lowerCamel
     *
     * @param tableName
     * @return
     */
    private String tableNameConvertUpperCamel(String tableName) {
        return CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, tableName.toLowerCase());
    }

}
