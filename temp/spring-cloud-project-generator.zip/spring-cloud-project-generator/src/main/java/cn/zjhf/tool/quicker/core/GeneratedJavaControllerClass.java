package cn.zjhf.tool.quicker.core;

import cn.zjhf.tool.quicker.dto.GeneratorParam;
import cn.zjhf.tool.quicker.dto.TableInfo;
import cn.zjhf.tool.quicker.model.DataModel;
import cn.zjhf.tool.quicker.model.JavaClassModel;
import cn.zjhf.tool.quicker.model.JavaImport;
import com.google.common.base.CaseFormat;
import com.google.common.base.Splitter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by lutiehua on 2017/9/28.
 */
public class GeneratedJavaControllerClass extends GeneratedFile {

    private JavaClassModel model;

    private String fileName;

    public GeneratedJavaControllerClass(GeneratorParam generatorParam) {
        super(generatorParam);
    }

    public GeneratedJavaControllerClass(GeneratorParam generatorParam, TableInfo tableInfo) {
        super(generatorParam);

        model = new JavaClassModel();

        Date now = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String date = dateFormat.format(now);
        String basePackageName = generatorParam.getPackageInfo().getBasePackage();
        String author = generatorParam.getPackageInfo().getAuthor();
        String controllerPackageName = generatorParam.getPackageInfo().getControllerPackage();
        String packageName = basePackageName + "." + controllerPackageName;

        String tableName = tableInfo.getName();
        String classRemark = tableInfo.getRemark();
        String modelClassName = CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, tableName.toLowerCase());
        String modelObjectName = CaseFormat.UPPER_CAMEL.to(CaseFormat.LOWER_CAMEL, modelClassName);
        String className = modelClassName + "Controller";
        String objectName = CaseFormat.UPPER_CAMEL.to(CaseFormat.LOWER_CAMEL, className);
        String serviceClassName = modelClassName + "Service";
        String serviceObjectName = CaseFormat.UPPER_CAMEL.to(CaseFormat.LOWER_CAMEL, serviceClassName);

        model.setPackageName(packageName);
        model.setAuthor(author);
        model.setDate(date);
        model.setClassName(className);
        model.setClassRemark(classRemark);
        model.setObjectName(objectName);
        model.setModelClassName(modelClassName);
        model.setModelObjectName(modelObjectName);
        model.setServiceClassName(serviceClassName);
        model.setServiceObjectName(serviceObjectName);

        // 分析依赖包
        List<JavaImport> importList = new ArrayList<>();
        JavaImport javaImport = null;

        // 实体类
        javaImport = new JavaImport();
        String modelPackageName = basePackageName + "." + generatorParam.getPackageInfo().getEntityPackage();
        javaImport.setName(modelPackageName + "." + modelClassName);
        importList.add(javaImport);

        // 服务类
        javaImport = new JavaImport();
        String servicePackageName = basePackageName + "." + generatorParam.getPackageInfo().getServicePackage();
        javaImport.setName(servicePackageName + "." + serviceClassName);
        importList.add(javaImport);

        model.setImports(importList);

        // 输出文件名称
        String rootDir = generatorParam.getPackageInfo().getProjectPath();
        String javaPath = generatorParam.getPackageInfo().getJavaPath();
        List<String> list = Splitter.on(".").splitToList(packageName);
        StringBuffer buffer = new StringBuffer();
        for (String path : list) {
            buffer.append(path);
            buffer.append("/");
        }
        String packagePath = buffer.toString();
        fileName = rootDir + "/" + javaPath + "/" + packagePath + className + ".java";
    }

    /**
     * 模板
     *
     * @return
     */
    @Override
    public String getTemplateName() {
        return "controller.ftl";
    }

    /**
     * 变量数据
     *
     * @return
     */
    @Override
    public DataModel getDataModel() {
        return model;
    }

    /**
     * 文件名称
     *
     * @return
     */
    @Override
    public String getFileName() {
        return fileName;
    }
}
